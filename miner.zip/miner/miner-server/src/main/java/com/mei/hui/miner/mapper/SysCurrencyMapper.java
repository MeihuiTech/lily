package com.mei.hui.miner.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mei.hui.miner.entity.Currency;
import org.springframework.stereotype.Repository;

@Repository
public interface SysCurrencyMapper extends BaseMapper<Currency> {

}