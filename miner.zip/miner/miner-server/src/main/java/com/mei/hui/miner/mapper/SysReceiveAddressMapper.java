package com.mei.hui.miner.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mei.hui.miner.entity.SysReceiveAddress;
import org.springframework.stereotype.Repository;

@Repository
public interface SysReceiveAddressMapper extends BaseMapper<SysReceiveAddress> {

}