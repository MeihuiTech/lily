package com.mei.hui.miner.entity;

import lombok.Data;

@Data
public class PoolInfo {

    private Long minerCount = 0L;

    private Long workerCount = 0L;

}
