package com.mei.hui.miner.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mei.hui.miner.entity.SwarmOneDayAgg;

public interface SwarmOneDayAggService extends IService<SwarmOneDayAgg> {
}
