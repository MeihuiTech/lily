package com.mei.hui.miner.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.mei.hui.miner.entity.FilReportGas;
import com.mei.hui.miner.feign.vo.ReportGasBO;
import com.mei.hui.util.Result;

/**
 * <p>
 * gas费用聚合 服务类
 * </p>
 *
 * @author 鲍红建
 * @since 2021-06-23
 */
public interface FilReportGasService extends IService<FilReportGas> {

    Result reportGas(ReportGasBO bo);

}
