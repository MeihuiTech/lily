package com.mei.hui.miner.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mei.hui.miner.entity.MrAggWithdraw;

public interface MrAggWithdrawMapper extends BaseMapper<MrAggWithdraw> {


}
