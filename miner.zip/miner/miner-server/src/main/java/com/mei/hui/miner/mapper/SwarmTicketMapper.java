package com.mei.hui.miner.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.mei.hui.miner.entity.SwarmTicket;
import org.springframework.stereotype.Repository;

@Repository
public interface SwarmTicketMapper extends BaseMapper<SwarmTicket> {

}